import React from 'react';

export default function PageAbout() {
  return <div>Page About</div>
}
